player1 = input("Masukkan role player 1: ")
if (player1 == "paladin"):
    hp1max = 100
    atk1 = 5
elif (player1 == "archer"):
    hp1max = 150
    atk1 = 5
else:
    hp1max = 100
    atk1 = 10

hp1 = int(input("Masukkan sisa HP player 1: "))
while hp1 > hp1max:
    print("HP Tidak Valid!")
    hp1 = int(input("Masukkan sisa HP player 1: "))

player2 = input("Masukkan role player 2: ")
if (player2 == "paladin"):
    hp2max = 100
    atk2 = 5
elif (player2 == "archer"):
    hp2max = 150
    atk2 = 5
else:
    hp2max = 100
    atk2 = 10

hp2 = int(input("Masukkan sisa HP player 2: "))
while hp2 > hp2max:
    print("HP Tidak Valid!")
    hp2 = int(input("Masukkan sisa HP player 2: "))

ronde = 0
while (hp1 > 0 and hp2 > 0):
    ronde += 1
    hp1 -= atk2
    hp2 -= atk1
    if (player1 == "paladin"):
        hp1 *= (110/100)
    if (player2 == "paladin"):
        hp2 *= (110/100)

if (hp1 <= 0 and hp2 <= 0):
    print("seri")
elif (hp1 <= 0):
    print(f"pemain 2 menang dalam {ronde} ronde")
else:
    print(f"pemain 1 menang dalam {ronde} ronde")