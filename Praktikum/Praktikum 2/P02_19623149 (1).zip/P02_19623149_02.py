n = 0
while n <= 0:
    n = int(input("Masukkan banyak segitiga: "))
    
for i in range(0, 3):
    for j in range(n):
        for k in range(i):
            print(end=" ")
        for k in range(5-i*2):
            print(end="*")
        for k in range(i):
            print(end=" ")
    print()