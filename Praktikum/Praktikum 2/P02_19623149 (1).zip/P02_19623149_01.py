a = int(input("Masukkan nilai A: "))
b = int(input("Masukkan nilai B: "))
x = int(input("Masukkan nilai x: ")) 
y = int(input("Masukkan nilai y: "))

summ = 0 
for i in range(a, b+1):
  if not(i % x) and not(i % y):
    summ += i
  
print(f"Jumlah bilangan yang habis dibagi oleh {x} dan {y} adalah {summ}.")