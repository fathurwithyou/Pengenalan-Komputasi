# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 5 Oktober 2023
# Deskripsi     : Program mencetak barisan unik sesuai soal

# KAMUS
# x, y, inc, cnt : integer
# naik : bool

# ALGORITMA
# menerima input
x = int(input("Masukkan x: "))
y = int(input("Masukkan y: "))

inc = y  # penambahan kelipatan
cnt = 0  # inisialisasi variabel counter
naik = True  # pengondisian baris bilangan

for i in range(x):  # loop sampai x
    if naik:  # jika masih naik
        cnt += 1
    else:  # jika masih turun
        cnt -= 1
    print(cnt, end=" ")  # cetak keluaran
    if cnt == y:  # jika sudah bertemu kelipatan y, maka turunkan nilainya dan tambahkan nilai kelipatannya
        naik = False
        y += inc
    if cnt == 1:  # jika sudah bertemu 1, maka naikkan kembali
        naik = True
