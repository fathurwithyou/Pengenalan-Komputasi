# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 5 Oktober 2023
# Deskripsi     : Program menentukan banyaknya kegiatan di gedung A dan gedung B

# KAMUS
# n, a, b, cnt, kegiatan_a, kegiatan_b, peserta : integer

# ALGORITMA
# menerima input
n = int(input("Masukkan nilai N: "))

# inisialisasi kegiatan yang tersisa
b = 3
a = 5
# variabel penghitung
cnt = 1
kegiatan_a = kegiatan_b = 0  # inisialisasi jumlah kegiatan
# proses
while b > 0:
    peserta = int(input(f"Masukkan peserta kegiatan ke-{cnt}: "))
    if peserta < n and a > 0:  # jika peserta < n dan masih bisa ada kegiatan di gedung A
        a -= 1
        kegiatan_a += 1
    else:  # jika masih bisa ada kegiatan di gedung B, maka kegiatan_b bertambah dan kapasitas kegiatan berkurang
        kegiatan_b += 1
        b -= 1
    cnt += 1  # penambahan urutan peserta

# cetak keluaran
print(
    f"Terdapat {kegiatan_a} kegiatan di gedung A dan {kegiatan_b} kegiatan di gedung B.")

'''
10
10
20
30

30
10
20
30
40
10
20
10
20

30
40
50
10
20
60
'''
