# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 5 Oktober 2023
# Deskripsi     : Program membuat piramida yang berisi huruf X dan angka

# KAMUS
# panjang, a, cnt, panjang_x, panjang_angka : integer

# ALGORITMA
# menerima input
panjang = int(input("Masukkan panjang piramida: "))
a = int(input("Masukkan selisih: "))

if panjang > 75:
    panjang = 75

cnt = 1  # inisialisasi angka awal
panjang_x = (panjang-1)//2  # inisialisasi awal panjang_x
panjang_angka = 1  # inisialisasi awal panjang_angka

while panjang_x >= 0:  # loop sampai tidak ada spasi setelahnya
    cnt %= 10  # ambil nilai satuannya saja
    for i in range(panjang_x):  # cetak huruf X
        print(end="X")
    for i in range(panjang_angka):  # cetak angka
        print(cnt, end="")
    for i in range(panjang_x):  # cetak huruf X
        print(end="X")
    panjang_x -= 1  # kurangi panjang X setiap perulangan
    panjang_angka += 2  # tambahkan panjang angka dengan 2 setiap perulangan
    cnt += a  # tambahkan nilai yang ingin dicetak dengan a
    print()  # cetak new line
