tanggal = int(input("Tanggal awal makan di resto: "))
tanggal = 30+1-tanggal

if tanggal <= 2:
  print("Poin tidak cukup untuk ditukarkan.")
else:
  print(end="Nona Deb mendapat ")
  if tanggal >= 10:
    print(f"{tanggal//10} Ramen",end="")
    tanggal %= 10
    if tanggal == 0: print(end='.')
    else: print(end=', ')
  if tanggal >= 5:
    print(f"{tanggal//5} Gyoza",end="")
    tanggal %= 5
    if tanggal == 0: print(end='.')
    else: print(end=', ')
  if tanggal >= 2:
    print(f"{tanggal//2} Ocha.")