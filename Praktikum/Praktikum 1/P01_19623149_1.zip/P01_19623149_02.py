pergi = int(input("Jam Keberangkatan Nona Deb: "))
pulang = int(input("Jam Kepulangan Nona Deb: "))

harga = 0
bus_pergi = bus_pulang =  ""
# pergi
if 6 <= pergi <= 8 or 15 <= pergi <= 17:
  bus_pergi = "Bus Universitas"
elif 7 <= pergi <= 18:
  bus_pergi = "Bus Kota"
  harga += 5000
else:
  bus_pergi = "Travel"
  harga += 10000

#pulang
if 6 <= pulang <= 8 or 15 <= pulang <= 17:
  bus_pulang = "Bus Universitas"
elif 7 <= pulang <= 18:
  bus_pulang = "Bus Kota"
  harga += 5000
else:
  bus_pulang = "Travel"
  harga += 10000
  
print(f"Nona Deb berangkat naik {bus_pergi} dan pulang naik {bus_pulang} dengan total biaya {harga}.")