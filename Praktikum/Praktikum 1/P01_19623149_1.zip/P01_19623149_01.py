a = int(input("Masukkan nilai resistor pertama: " ))
b = int(input("Masukkan nilai resistor kedua: " ))
c = int(input("Masukkan nilai resistor ketiga: " ))

if a == 0 or b == 0 or c==0:
  print("Tidak dapat menghitung hambatan.")
else:
  print(f"Total hambatan rangkaian adalah {(a*b*c)/(b*c+a*b+a*c)} ohm.")