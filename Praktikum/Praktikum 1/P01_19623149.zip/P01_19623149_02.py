# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 21 September 2023
# Deskripsi     : Program menentukan angka spesial

# KAMUS
# n, a, b, c, d : integer

# ALGORITMA
# menerima input
n = int(input("Masukkan Angka: "))

# mengambil setiap digit
a = n//1000 % 10
b = n//100 % 10
c = n//10 % 10
d = n % 10

if (a*d) % (b+c) == 0:
    print(f"Angka {n} adalah angka spesial.")
else:
    print(f"Angka {n} bukan angka spesial.")

'''
6117

2139

8225

'''
