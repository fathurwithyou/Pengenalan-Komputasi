# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 21 September 2023
# Deskripsi     : Program menentukan uang rupiah yang lebih banyak

# KAMUS
# peng, kom, uang_peng, uang_kom : float

# ALGORITMA
# menerima input
peng = float(input("Banyak uang Peng yang ditawarkan: "))
kom = float(input("Banyak uang Kom yang ditawarkan:"))
uang_peng = float(input("Konversi mata uang Peng ke rupiah: "))
uang_kom = float(input("Konversi mata uang Kom ke rupiah: "))

# proses
uang_peng *= peng
uang_kom *= kom

if uang_peng > uang_kom:
    print("Adik Tuan Kil memilih uang Peng.")
else:
    print("Adik Tuan Kil memilih uang Kom.")

'''
1000
500
10000
5000

10
50
10000
10000

1000
100
100
10000
'''
