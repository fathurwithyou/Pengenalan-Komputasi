# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 21 September 2023
# Deskripsi     : Program menentukan banyaknya ukuran yang bisa dibuat

# KAMUS
# kain, pita : float
# insuff : boolean
# s, m, l: integer


# ALGORITMA
# menerima input
kain = float(input("Jumlah Kain : "))
pita = float(input("Jumlah Pita : "))

# proses
s = m = l = 1
kain -= 4.7
pita -= 3.1
insuff = False

if kain < 0 or pita < 0:
    print("Bahan tidak cukup untuk membuat baju.")
    insuff = True
# habiskan untuk l
if not insuff:
    # Ukuran L
    if kain >= 2 and pita >= 1.3:
        # ambil minimum
        mini = 0
        if pita//1.3 > kain//2:
            mini = kain//2
        else:
            mini = pita//1.3
        l += mini
        kain -= mini*2
        pita -= mini*1.3

    # Ukuran M
    if kain >= 1.5 and pita >= 1:
        # ambil minimum
        mini = 0
        if pita//1 > kain//1.5:
            mini = kain//1.5
        else:
            mini = pita//1
        m += mini
        kain -= mini*1.5
        pita -= mini*1

    # Ukuran S
    if kain >= 1.2 and pita >= 0.8:
        # ambil minimum
        mini = 0
        if pita//0.8 > kain//1.2:
            mini = kain//1.2
        else:
            mini = pita//0.8
        s += mini
        kain -= mini*1.2
        pita -= mini*0.8
    print(
        f"Nona Deb dapat membuat {int(s)} ukuran S, {int(m)} ukuran M, {int(l)} ukuran L.")

'''
12
8

5
4

10
3
'''
