# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 21 September 2023
# Deskripsi     : Program membuat pola dari nilai H

# KAMUS
# H, cnt, l, r : integer

# ALGORITMA
# menerima input
h = int(input("Masukkan nilai H: "))
cnt = 1
if h % 2:
    l = h//2+1
    r = h//2
else:
    l = r = h//2

for i in range(l):
    for j in range(i+1):
        print(cnt, end=" ")
        cnt += 1
    print()
for i in range(r, 0, -1):
    for j in range(i):
        print(cnt, end=" ")
        cnt += 1
    print()