# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 21 September 2023
# Deskripsi     : Program menentukan apakah N bilangan pangkat k

# KAMUS
# n, k, n_out : integer
# pangkat : boolean

# ALGORITMA
# menerima input
n = int(input("Masukkan bilangan N: "))
k = int(input("Masukkan nilai k: "))
n_out = n
pangkat = True
while n != 1:
    if (n % k):
        pangkat = False
        break
    n /= k
if pangkat:
    print(f"{n_out} merupakan perpangkatan {k}.")
else:
    print(f"{n_out} bukan merupakan perpangkatan {k}.")
