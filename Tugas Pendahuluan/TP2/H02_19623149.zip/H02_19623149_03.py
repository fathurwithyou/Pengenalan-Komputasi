# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 21 September 2023
# Deskripsi     : Program menentukan  apakah dapat mencapai N dengan cara mengalikan A dengan B secara bergantian

# KAMUS
# a, b, n, n_out, pangkat : integer
# lower : boolean

# ALGORITMA
# menerima input
a = int(input("Masukkan bilangan A: "))
b = int(input("Masukkan bilangan B: "))
n = int(input("Masukkan bilangan N: "))

# proses
n_out = n
pangkat = 0
lower = False
if n < a*b:
    lower = True
while n >= a*b:
    pangkat += 1
    n //= a*b
if a**(pangkat+1)*b**(pangkat) == n_out or a**(pangkat)*b**(pangkat+1) == n_out or (a**pangkat)*(b**pangkat) == n_out and not lower:
    print(f"Bilangan {n_out} dapat dicapai.")
else:
    print(f"Bilangan {n_out} tidak dapat dicapai.")
