# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 11 September 2023
# Deskripsi     : Program yang menentukan kelulusan Tuan Kil dari nilai yang diberikan

# KAMUS
# a, b, c, d : float

# menerima input
a = float(input("Masukkan nilai ujian 1: "))
b = float(input("Masukkan nilai ujian 2: "))
c = float(input("Masukkan nilai ujian 3: "))
d = float(input("Masukkan nilai ujian 4: "))

if (a+b+c+d >= 280 and a >= 50 and b >= 50 and c >= 50 and d >= 50):
    print("Tuan Kil lulus kelas Tuan Leo.")
else:
    print("Tuan Kil tidak lulus kelas Tuan Leo.")
