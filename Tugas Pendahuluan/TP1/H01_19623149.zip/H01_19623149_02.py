# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 11 September 2023
# Deskripsi     : Program yang menentukan jenis garis yang dihasilkan dari kedua titik

# KAMUS
# x1, x2, y1, y2, dx, dy : float

# ALGORITMA
# menerima input
x1 = float(input("Masukkan x1: "))
y1 = float(input("Masukkan y1: "))
x2 = float(input("Masukkan x2: "))
y2 = float(input("Masukkan y2: "))

# mencari delta
dx = x2-x1
dy = y2-y1

# proses
if dy == 0:
    print("Garis tersebut merupakan garis horizontal.")
elif dx == 0:
    print("Garis tersebut merupakan garis vertikal.")
else:
    print(f"Garis tersebut memiliki gradien {dy/dx}.")
