# NIM/Nama      : 19623149/Muhammad Fathur Rizky
# Tanggal       : 11 September 2023
# Deskripsi     : Program yang menentukan harga kursi berdasarkan nomor dan posisi kursi

# KAMUS
# nomor, posisi, harga : integer
# kelas : string


# ALGORITMA
# menerima input
nomor = int(input("Tentukan Nomor Kursi: "))
posisi = input("Tentukan Posisi Kursi: ")

# inisialisasi
harga = 0
kelas = ""

# proses
if 1 <= nomor <= 20 or 51 <= nomor <= 60:
    kelas = "Hot Seat"
    if posisi == 'A' or posisi == 'F':
        harga = 1600
    elif posisi == 'B' or posisi == 'E':
        harga = 1550
    elif posisi == 'C' or posisi == 'D':
        harga = 1500
elif 21 <= nomor <= 50 or 61 <= nomor <= 100:
    kelas = "Regular"
    if posisi == 'A' or posisi == 'F':
        harga = 1000
    elif posisi == 'B' or posisi == 'E':
        harga = 950
    elif posisi == 'C' or posisi == 'D':
        harga = 900
print(f"Tuan Kil memilih kursi {kelas} dengan harga {harga*1000}.")
