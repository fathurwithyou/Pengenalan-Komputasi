x1 = int(input("Masukkan x1: "))
y1 = int(input("Masukkan y1: "))
x2 = int(input("Masukkan x2: "))
y2 = int(input("Masukkan y2: "))

dx = x2-x1
dy = y2-y1

if dy == 0:
    print("Garis tersebut merupakan garis horizontal .")
elif dx == 0:
    print("Garis tersebut merupakan garis vertikal.")
else:
    print(f"Garis tersebut memiliki gradien {dy/dx}.")
